package demo;

/**
 *
 * @author jvelez
 */
public class BurgerSelfOrderKioskExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BurgerSelfOrderKioskManager atm = new BurgerSelfOrderKioskManager();
        atm.run();
    }
    
}
